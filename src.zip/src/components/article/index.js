import React from "react";
import styles from "./style.module.css";
import Heading from "../heading";
import { Link } from "react-router-dom";
import Filter from "../filter";

const ArticleData = [
  {
    title: "Introduction to Product",
  },
  {
    title: "Tutorials for Beginners",
  },
  {
    title: "Moving to Bolt System",
  },
  {
    title: "Accessibility",
  },
  {
    title: "Content Management",
  },
  {
    title: "Generating Reports",
  },
];

const Article = () => {
  return (
    <div className={styles.article_main}>
      <div className={styles.back_btn}>
        <span> &#8592;</span>Back
      </div>

      <Heading title={"Women Clothes"} btnblue={false} btnWhite={false} />
      <div className={styles.article_left}>
        {ArticleData.map((value, index) => (
          <Link key={index} to={"#"} className={styles.article_left_data}>
            {value.title}
          </Link>
        ))}
      </div>
      <div className={styles.article_right}>
        <Filter select={false} button={false} />
        <div className={styles.article_right_content}>
          <div className={styles.arc_first_box}>
            <div className={styles.arc_title}>Introduction to Product</div>
            <div className={styles.arc_description}>
              Bolt is content management system, or CMS. Subscription includes
              content hosting, professionally designed layouts, 24/7 support,
              and access to our user-friendly platform for managing your
              business. You can use bolt to create management systems.
            </div>
            <div className={styles.arc_message}>
              Recommended: <br />
              You can learn faster by looking some onboarding videos in video
              gallery.
            </div>
            <hr className={styles.rectangle} />
          </div>

          <div className={styles.arc_second_box}>
            <div className={styles.arc_title}>Starting Guide</div>
            <div className={styles.arc_description}>
              You can choose from a range of billing plans to get your idea
              working, whether you’re starting with a website or launching a new
              business.
            </div>
            <div className={styles.arc_message_wrapper}>
              <span>1</span>
              <div className={styles.arc_description}>
                All billing plans are available on monthly and annual payment
                cycles. On an annual billing cycle, the average monthly cost is
                lower, and you can get a 3 months free.
              </div>
            </div>

            <div className={styles.arc_message_wrapper}>
              <span>2</span>
              <div className={styles.arc_description}>
                Upgrade to paid service to make your site public. If you need
                more time to design your site before going live, you can hide it
                behind a password.
              </div>
            </div>

            <div className={styles.arc_message_wrapper}>
              <span>3</span>
              <div className={styles.arc_description}>
                Site has a trial period. Trial period is free two-week period
                where you can explore the platform, upload content, experiment
                with ecommerce website.
              </div>
            </div>
            <hr className={styles.rectangle} />
          </div>

          <div className={styles.arc_third_box}>
            <div className={styles.arc_title}>Additional Information</div>
            <div className={styles.arc_tabs_wrapper}>
              <Link to={"#"} className={styles.tab}>
                Onboarding
              </Link>
              <Link to={"#"} className={styles.tab}>
                Tutorials
              </Link>
              <Link to={"#"} className={styles.tab}>
                Guides for Beginners
              </Link>
            </div>
            <div className={styles.arc_description}>
              Introduction to Product
            </div>
            <div className={styles.arc_message}>
              Recommended: <br />
              You can learn faster by looking some onboarding videos in video
              gallery.
            </div>
            <hr className={styles.rectangle} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Article;
