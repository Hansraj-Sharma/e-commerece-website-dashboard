import React from "react";
import styles from "./style.module.css";
import Heading from "../heading";

const Reports = () => {
  return (
    <div className={styles.reports_main}>
      <Heading title={"Reports"} btnTitle2={"Export Report"} btnWhite={false} />
      <div></div>
    </div>
  );
};

export default Reports;
